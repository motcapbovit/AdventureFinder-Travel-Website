package com.example.websitedattourdulich.serviceimpl;

import org.springframework.stereotype.Service;

@Service
public class DestinationServiceImpl {

}

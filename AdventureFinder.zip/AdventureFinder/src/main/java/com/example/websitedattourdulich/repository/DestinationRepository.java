package com.example.websitedattourdulich.repository;

public interface DestinationRepository {

}

package com.example.websitedattourdulich;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebsiteDatTourDuLichApplicationTests {

    @Test
    void contextLoads() {
    }

}

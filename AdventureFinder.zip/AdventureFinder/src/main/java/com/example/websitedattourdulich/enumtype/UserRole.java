package com.example.websitedattourdulich.enumtype;

public enum UserRole {
    USER,
    ADMIN,
    MANAGER
}

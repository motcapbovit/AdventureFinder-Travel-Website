package com.example.websitedattourdulich.service;

public interface DestinationService {

}

package com.example.websitedattourdulich;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebsiteDatTourDuLichApplication {

    public static void main(String[] args) {
        SpringApplication.run(WebsiteDatTourDuLichApplication.class, args);
    }

}

package com.example.websitedattourdulich.utilities;


import com.example.websitedattourdulich.dto.UserDTO;
import com.example.websitedattourdulich.entity.User;

public class ConvertUserToDto {
	
	public static UserDTO convertUsertoDto(User user) {
		return new UserDTO(user.getId(),user.getUsername(), user.getHo_ten(), user.getSdt(), user.getGioi_tinh(), user.getEmail(),
				user.getDia_chi(), user.getRole());
	}
	
}
